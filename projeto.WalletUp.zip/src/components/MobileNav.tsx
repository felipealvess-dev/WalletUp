import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, ArrowLeftRight, BarChart3, Settings, Plus } from "lucide-react";
import { useState } from "react";
import { TransactionModal } from "./TransactionModal";

const items = [
  { to: "/", label: "Início", icon: LayoutDashboard },
  { to: "/transactions", label: "Transações", icon: ArrowLeftRight },
];
const items2 = [
  { to: "/reports", label: "Relatórios", icon: BarChart3 },
  { to: "/settings", label: "Config", icon: Settings },
];

export function MobileNav() {
  const path = useRouterState({ select: (r) => r.location.pathname });
  const [open, setOpen] = useState(false);

  const Item = ({ to, label, Icon }: { to: string; label: string; Icon: any }) => {
    const active = to === "/" ? path === "/" : path.startsWith(to);
    return (
      <Link to={to} className={"flex flex-col items-center gap-0.5 text-[10px] " + (active ? "text-primary" : "text-muted-foreground")}>
        <Icon className="h-5 w-5" />
        {label}
      </Link>
    );
  };

  return (
    <>
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-sidebar border-t border-sidebar-border flex items-center justify-around py-2 pb-[max(env(safe-area-inset-bottom),0.5rem)]">
        {items.map((it) => <Item key={it.to} to={it.to} label={it.label} Icon={it.icon} />)}
        <button
          onClick={() => setOpen(true)}
          className="-mt-6 h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/30"
          aria-label="Adicionar"
        >
          <Plus className="h-6 w-6" />
        </button>
        {items2.map((it) => <Item key={it.to} to={it.to} label={it.label} Icon={it.icon} />)}
      </nav>
      <TransactionModal open={open} onOpenChange={setOpen} />
    </>
  );
}
