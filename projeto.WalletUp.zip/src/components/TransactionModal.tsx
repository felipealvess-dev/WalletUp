import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { useFinance } from "@/lib/finance/context";
import { PAYMENT_LABEL } from "@/lib/finance/categories";
import { todayISO } from "@/lib/finance/format";
import type { PaymentMethod, Recurrence, Transaction, TxType } from "@/lib/finance/types";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editing?: Transaction;
}

export function TransactionModal({ open, onOpenChange, editing }: Props) {
  const { data, addTransaction, updateTransaction } = useFinance();
  const [type, setType] = useState<TxType>("expense");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [date, setDate] = useState(todayISO());
  const [payment, setPayment] = useState<PaymentMethod>("pix");
  const [notes, setNotes] = useState("");
  const [recurring, setRecurring] = useState(false);
  const [recurrence, setRecurrence] = useState<Recurrence>("monthly");

  useEffect(() => {
    if (!open) return;
    if (editing) {
      setType(editing.type);
      setDescription(editing.description);
      setAmount(String(editing.amount));
      setCategoryId(editing.categoryId);
      setDate(editing.date);
      setPayment(editing.payment);
      setNotes(editing.notes ?? "");
      setRecurring(editing.recurrence !== "none");
      setRecurrence(editing.recurrence === "none" ? "monthly" : editing.recurrence);
    } else {
      setType("expense");
      setDescription("");
      setAmount("");
      setCategoryId("");
      setDate(todayISO());
      setPayment("pix");
      setNotes("");
      setRecurring(false);
      setRecurrence("monthly");
    }
  }, [open, editing]);

  const cats = data.categories.filter((c) => c.type === type);
  useEffect(() => {
    if (!cats.find((c) => c.id === categoryId)) setCategoryId(cats[0]?.id ?? "");
  }, [type]); // eslint-disable-line

  const submit = () => {
    const value = parseFloat(amount.replace(",", "."));
    if (!description.trim()) return toast.error("Descrição obrigatória");
    if (!value || value <= 0) return toast.error("Valor deve ser maior que zero");
    if (!categoryId) return toast.error("Selecione uma categoria");
    if (!date) return toast.error("Data obrigatória");

    const payload = {
      type, description: description.trim(), amount: value, categoryId, date, payment,
      notes: notes.trim() || undefined,
      recurrence: recurring ? recurrence : ("none" as Recurrence),
    };
    if (editing) {
      updateTransaction(editing.id, payload);
      toast.success("Transação atualizada");
    } else {
      addTransaction(payload);
      toast.success("Transação adicionada");
    }
    onOpenChange(false);
  };

  const isIncome = type === "income";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{editing ? "Editar transação" : "Nova transação"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className={cn("p-1 rounded-full grid grid-cols-2 text-sm font-medium", isIncome ? "bg-emerald-500/10" : "bg-red-500/10")}>
            <button
              onClick={() => setType("income")}
              className={cn("py-2 rounded-full transition", isIncome ? "bg-emerald-500 text-white" : "text-muted-foreground")}
            >🟢 Entrada</button>
            <button
              onClick={() => setType("expense")}
              className={cn("py-2 rounded-full transition", !isIncome ? "bg-red-500 text-white" : "text-muted-foreground")}
            >🔴 Saída</button>
          </div>

          <div className="grid gap-2">
            <Label>Descrição</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ex: Supermercado" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Valor</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">R$</span>
                <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} className="pl-9" placeholder="0,00" />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Data</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Categoria</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {cats.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      <span className="mr-2">{c.icon}</span>{c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Forma de pagamento</Label>
              <Select value={payment} onValueChange={(v) => setPayment(v as PaymentMethod)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(PAYMENT_LABEL).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-2">
            <Label>Observações</Label>
            <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>

          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <div className="text-sm font-medium">Recorrente</div>
              <div className="text-xs text-muted-foreground">Repetir esta transação</div>
            </div>
            <Switch checked={recurring} onCheckedChange={setRecurring} />
          </div>

          {recurring && (
            <div className="grid gap-2">
              <Label>Frequência</Label>
              <Select value={recurrence} onValueChange={(v) => setRecurrence(v as Recurrence)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Diário</SelectItem>
                  <SelectItem value="weekly">Semanal</SelectItem>
                  <SelectItem value="monthly">Mensal</SelectItem>
                  <SelectItem value="yearly">Anual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button className="flex-1" onClick={submit}>{editing ? "Salvar" : "Adicionar"}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
