import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, Download, Pencil, Trash2, Plus, ArrowUpDown } from "lucide-react";
import { toast } from "sonner";
import { useCategoryMap, useFinance } from "@/lib/finance/context";
import { formatBRL, formatDate } from "@/lib/finance/format";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { TransactionModal } from "@/components/TransactionModal";
import { EmptyState } from "@/components/EmptyState";
import { cn } from "@/lib/utils";
import type { Transaction } from "@/lib/finance/types";

export const Route = createFileRoute("/transactions")({
  head: () => ({
    meta: [
      { title: "Transações — FinanceFlow" },
      { name: "description", content: "Gerencie todas as suas transações financeiras." },
    ],
  }),
  component: TransactionsPage,
});

function TransactionsPage() {
  const { data, deleteTransaction, deleteMany, restoreTransaction } = useFinance();
  const catMap = useCategoryMap();

  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [catFilter, setCatFilter] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [sortBy, setSortBy] = useState<"date" | "amount" | "category">("date");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Transaction | undefined>();

  const filtered = useMemo(() => {
    let r = data.transactions.filter((t) => {
      if (query && !t.description.toLowerCase().includes(query.toLowerCase())) return false;
      if (typeFilter !== "all" && t.type !== typeFilter) return false;
      if (catFilter !== "all" && t.categoryId !== catFilter) return false;
      if (from && t.date < from) return false;
      if (to && t.date > to) return false;
      if (min && t.amount < parseFloat(min)) return false;
      if (max && t.amount > parseFloat(max)) return false;
      return true;
    });
    r = [...r].sort((a, b) => {
      let cmp = 0;
      if (sortBy === "date") cmp = a.date.localeCompare(b.date);
      else if (sortBy === "amount") cmp = a.amount - b.amount;
      else cmp = (catMap.get(a.categoryId)?.name ?? "").localeCompare(catMap.get(b.categoryId)?.name ?? "");
      return sortDir === "asc" ? cmp : -cmp;
    });
    return r;
  }, [data.transactions, query, typeFilter, catFilter, from, to, min, max, sortBy, sortDir, catMap]);

  const perPage = 10;
  const pages = Math.max(1, Math.ceil(filtered.length / perPage));
  const slice = filtered.slice((page - 1) * perPage, page * perPage);

  const toggleAll = () => {
    if (slice.every((t) => selected.has(t.id))) {
      const ns = new Set(selected);
      slice.forEach((t) => ns.delete(t.id));
      setSelected(ns);
    } else {
      const ns = new Set(selected);
      slice.forEach((t) => ns.add(t.id));
      setSelected(ns);
    }
  };
  const toggleOne = (id: string) => {
    const ns = new Set(selected);
    ns.has(id) ? ns.delete(id) : ns.add(id);
    setSelected(ns);
  };

  const handleDelete = (id: string) => {
    const removed = deleteTransaction(id);
    if (removed) {
      toast.success("Transação excluída", {
        action: { label: "Desfazer", onClick: () => restoreTransaction(removed) },
        duration: 5000,
      });
    }
  };

  const handleBulkDelete = () => {
    deleteMany(Array.from(selected));
    toast.success(`${selected.size} transação(ões) excluídas`);
    setSelected(new Set());
  };

  const exportCsv = () => {
    const header = ["Data", "Tipo", "Descrição", "Categoria", "Pagamento", "Valor"];
    const rows = filtered.map((t) => [
      t.date,
      t.type === "income" ? "Entrada" : "Saída",
      `"${t.description.replace(/"/g, '""')}"`,
      catMap.get(t.categoryId)?.name ?? "",
      t.payment,
      t.amount.toFixed(2),
    ]);
    const csv = [header, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `transacoes-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleSort = (k: "date" | "amount" | "category") => {
    if (sortBy === k) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else { setSortBy(k); setSortDir("desc"); }
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-[1400px] mx-auto">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Transações</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} resultado(s)</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCsv} className="gap-2"><Download className="h-4 w-4" /> Exportar</Button>
          <Button onClick={() => { setEditing(undefined); setOpen(true); }} className="gap-2"><Plus className="h-4 w-4" /> Nova</Button>
        </div>
      </header>

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid gap-3 md:grid-cols-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }} placeholder="Buscar descrição..." className="pl-9" />
            </div>
            <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setPage(1); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos tipos</SelectItem>
                <SelectItem value="income">Entradas</SelectItem>
                <SelectItem value="expense">Saídas</SelectItem>
              </SelectContent>
            </Select>
            <Select value={catFilter} onValueChange={(v) => { setCatFilter(v); setPage(1); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas categorias</SelectItem>
                {data.categories.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-3 md:grid-cols-4">
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} placeholder="De" />
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} placeholder="Até" />
            <Input inputMode="decimal" value={min} onChange={(e) => setMin(e.target.value)} placeholder="Valor mín." />
            <Input inputMode="decimal" value={max} onChange={(e) => setMax(e.target.value)} placeholder="Valor máx." />
          </div>
        </CardContent>
      </Card>

      {selected.size > 0 && (
        <div className="flex items-center justify-between p-3 rounded-lg bg-primary/10 border border-primary/30">
          <span className="text-sm">{selected.size} selecionada(s)</span>
          <Button variant="destructive" size="sm" onClick={handleBulkDelete} className="gap-2"><Trash2 className="h-4 w-4" /> Excluir</Button>
        </div>
      )}

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          {filtered.length === 0 ? (
            <EmptyState title="Nenhuma transação encontrada" description="Ajuste os filtros ou adicione uma nova." />
          ) : (
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-muted-foreground border-b border-border">
                <tr>
                  <th className="px-4 py-3 text-left"><Checkbox checked={slice.length > 0 && slice.every((t) => selected.has(t.id))} onCheckedChange={toggleAll} /></th>
                  <th className="px-4 py-3 text-left"><button className="inline-flex items-center gap-1" onClick={() => toggleSort("date")}>Data <ArrowUpDown className="h-3 w-3" /></button></th>
                  <th className="px-4 py-3 text-left">Descrição</th>
                  <th className="px-4 py-3 text-left"><button className="inline-flex items-center gap-1" onClick={() => toggleSort("category")}>Categoria <ArrowUpDown className="h-3 w-3" /></button></th>
                  <th className="px-4 py-3 text-right"><button className="inline-flex items-center gap-1" onClick={() => toggleSort("amount")}>Valor <ArrowUpDown className="h-3 w-3" /></button></th>
                  <th className="px-4 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody>
                {slice.map((t) => {
                  const c = catMap.get(t.categoryId);
                  return (
                    <tr key={t.id} className="border-b border-border hover:bg-accent/30">
                      <td className="px-4 py-3"><Checkbox checked={selected.has(t.id)} onCheckedChange={() => toggleOne(t.id)} /></td>
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{formatDate(t.date)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{c?.icon ?? "💸"}</span>
                          <span className="font-medium">{t.description}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="secondary" style={{ backgroundColor: (c?.color ?? "#71717A") + "22", color: c?.color }}>{c?.name ?? "—"}</Badge>
                      </td>
                      <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", t.type === "income" ? "text-emerald-500" : "text-red-500")}>
                        {t.type === "income" ? "+" : "−"} {formatBRL(t.amount)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setEditing(t); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(t.id)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      {pages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">Página {page} de {pages}</div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>Anterior</Button>
            <Button variant="outline" size="sm" disabled={page === pages} onClick={() => setPage((p) => p + 1)}>Próxima</Button>
          </div>
        </div>
      )}

      <TransactionModal open={open} onOpenChange={setOpen} editing={editing} />
    </div>
  );
}
