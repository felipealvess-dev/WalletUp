import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Download, Upload, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useFinance } from "@/lib/finance/context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Configurações — FinanceFlow" },
      { name: "description", content: "Personalize o FinanceFlow." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { data, updateSettings, replaceAll, reset } = useFinance();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `financeflow-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
    toast.success("Dados exportados");
  };

  const importJson = async (file: File) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!parsed.transactions || !parsed.categories || !parsed.settings) throw new Error("Formato inválido");
      replaceAll(parsed);
      toast.success("Dados importados");
    } catch (e: any) {
      toast.error("Erro ao importar: " + e.message);
    }
  };

  const doReset = () => {
    if (confirmText !== "DELETAR") return toast.error("Digite DELETAR para confirmar");
    reset();
    setConfirmOpen(false);
    setConfirmText("");
    toast.success("Dados apagados");
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-3xl mx-auto">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-sm text-muted-foreground">Personalize sua experiência.</p>
      </header>

      <Card>
        <CardHeader><CardTitle>Perfil & App</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label>Nome do perfil</Label>
            <Input value={data.settings.profileName} onChange={(e) => updateSettings({ profileName: e.target.value })} />
          </div>
          <div className="grid gap-2">
            <Label>Nome do app</Label>
            <Input value={data.settings.appName} onChange={(e) => updateSettings({ appName: e.target.value })} />
          </div>
          <div className="grid gap-2">
            <Label>Moeda</Label>
            <Input value={data.settings.currency} onChange={(e) => updateSettings({ currency: e.target.value })} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Aparência & Notificações</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div><div className="text-sm font-medium">Modo escuro</div><div className="text-xs text-muted-foreground">Tema padrão do app</div></div>
            <Switch checked={data.settings.theme === "dark"} onCheckedChange={(v) => updateSettings({ theme: v ? "dark" : "light" })} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div><div className="text-sm font-medium">Alertas de orçamento</div><div className="text-xs text-muted-foreground">Receber avisos quando passar de 80%</div></div>
            <Switch checked={data.settings.budgetAlerts} onCheckedChange={(v) => updateSettings({ budgetAlerts: v })} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Gerenciamento de dados</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" onClick={exportJson} className="w-full justify-start gap-2"><Download className="h-4 w-4" /> Exportar dados (JSON)</Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()} className="w-full justify-start gap-2"><Upload className="h-4 w-4" /> Importar dados (JSON)</Button>
          <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={(e) => e.target.files?.[0] && importJson(e.target.files[0])} />
          <Button variant="destructive" onClick={() => setConfirmOpen(true)} className="w-full justify-start gap-2"><Trash2 className="h-4 w-4" /> Limpar todos os dados</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Sobre</CardTitle></CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-1">
          <p><strong className="text-foreground">FinanceFlow</strong> v1.0.0</p>
          <p>App de gerenciamento de finanças pessoais. Dados armazenados localmente no seu navegador.</p>
        </CardContent>
      </Card>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Apagar todos os dados</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">Esta ação não pode ser desfeita. Digite <strong className="text-foreground">DELETAR</strong> para confirmar.</p>
            <Input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="DELETAR" />
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setConfirmOpen(false)}>Cancelar</Button>
              <Button variant="destructive" className="flex-1" onClick={doReset}>Apagar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
