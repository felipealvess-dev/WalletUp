import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, AlertTriangle, Pencil } from "lucide-react";
import { toast } from "sonner";
import { useFinance } from "@/lib/finance/context";
import { formatBRL, fullMonthLabel, monthKey } from "@/lib/finance/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export const Route = createFileRoute("/budgets")({
  head: () => ({
    meta: [
      { title: "Orçamentos — FinanceFlow" },
      { name: "description", content: "Acompanhe seus orçamentos mensais por categoria." },
    ],
  }),
  component: BudgetsPage,
});

function BudgetsPage() {
  const { data, updateCategory } = useFinance();
  const now = new Date();
  const [cursor, setCursor] = useState({ y: now.getFullYear(), m: now.getMonth() });
  const key = `${cursor.y}-${String(cursor.m + 1).padStart(2, "0")}`;
  const [editId, setEditId] = useState<string | null>(null);
  const [budget, setBudget] = useState("");

  const monthEnd = new Date(cursor.y, cursor.m + 1, 0);
  const today = new Date();
  const daysInMonth = monthEnd.getDate();
  const isCurrent = today.getFullYear() === cursor.y && today.getMonth() === cursor.m;
  const dayOfMonth = isCurrent ? today.getDate() : daysInMonth;
  const daysLeft = Math.max(0, daysInMonth - dayOfMonth);

  const spentByCat = useMemo(() => {
    const m = new Map<string, number>();
    for (const t of data.transactions) {
      if (monthKey(t.date) !== key || t.type !== "expense") continue;
      m.set(t.categoryId, (m.get(t.categoryId) ?? 0) + t.amount);
    }
    return m;
  }, [data.transactions, key]);

  const budgeted = data.categories.filter((c) => c.type === "expense" && c.budget);
  const totalBudget = budgeted.reduce((s, c) => s + (c.budget ?? 0), 0);
  const totalSpent = budgeted.reduce((s, c) => s + (spentByCat.get(c.id) ?? 0), 0);
  const totalPct = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;
  const overspent = budgeted.filter((c) => (spentByCat.get(c.id) ?? 0) > (c.budget ?? 0));

  const colorFor = (pct: number) => (pct < 70 ? "#22C55E" : pct < 90 ? "#EAB308" : "#EF4444");

  const move = (n: number) => {
    const d = new Date(cursor.y, cursor.m + n, 1);
    setCursor({ y: d.getFullYear(), m: d.getMonth() });
  };

  const openEdit = (id: string, current?: number) => {
    setEditId(id); setBudget(current ? String(current) : "");
  };
  const saveBudget = () => {
    const v = budget ? parseFloat(budget.replace(",", ".")) : undefined;
    if (editId) updateCategory(editId, { budget: v });
    setEditId(null);
    toast.success("Orçamento atualizado");
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-[1400px] mx-auto">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Orçamentos</h1>
          <p className="text-sm text-muted-foreground">Controle seus limites de gastos mensais.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => move(-1)}><ChevronLeft className="h-4 w-4" /></Button>
          <div className="font-semibold w-44 text-center">{fullMonthLabel(key)}</div>
          <Button variant="outline" size="icon" onClick={() => move(1)}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </header>

      {overspent.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Atenção</AlertTitle>
          <AlertDescription>
            {overspent.length} categoria(s) ultrapassaram o orçamento: {overspent.map((c) => c.name).join(", ")}.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader><CardTitle>Visão geral</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-baseline">
            <div className="text-3xl font-bold tabular-nums">{formatBRL(totalSpent)}</div>
            <div className="text-sm text-muted-foreground">de {formatBRL(totalBudget)}</div>
          </div>
          <Progress value={Math.min(100, totalPct)} className="h-3" style={{ ["--progress-color" as any]: colorFor(totalPct) }} />
          <div className="text-xs text-muted-foreground">{daysLeft} dia(s) restantes neste mês</div>
        </CardContent>
      </Card>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {data.categories.filter((c) => c.type === "expense").map((c) => {
          const spent = spentByCat.get(c.id) ?? 0;
          const has = !!c.budget;
          const pct = has ? Math.min(100, (spent / c.budget!) * 100) : 0;
          const projection = isCurrent && dayOfMonth > 0 ? (spent / dayOfMonth) * daysInMonth : spent;
          return (
            <Card key={c.id}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl flex items-center justify-center text-lg" style={{ backgroundColor: c.color + "22" }}>{c.icon}</div>
                    <div className="font-medium">{c.name}</div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => openEdit(c.id, c.budget)}><Pencil className="h-4 w-4" /></Button>
                </div>
                {has ? (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="font-semibold tabular-nums">{formatBRL(spent)}</span>
                      <span className="text-muted-foreground">/ {formatBRL(c.budget!)}</span>
                    </div>
                    <Progress value={pct} className="h-2" style={{ ["--progress-color" as any]: colorFor(pct) }} />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Projeção: {formatBRL(projection)}</span>
                      <span style={{ color: colorFor(pct) }}>{pct.toFixed(0)}%</span>
                    </div>
                  </>
                ) : (
                  <div className="text-sm text-muted-foreground">Sem orçamento definido. Clique no lápis para definir.</div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={!!editId} onOpenChange={(o) => !o && setEditId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Definir orçamento mensal</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Label>Valor (R$)</Label>
            <Input value={budget} onChange={(e) => setBudget(e.target.value)} placeholder="0,00" />
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setEditId(null)}>Cancelar</Button>
              <Button className="flex-1" onClick={saveBudget}>Salvar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
