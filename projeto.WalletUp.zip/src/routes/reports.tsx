import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Download } from "lucide-react";
import {
  CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { useCategoryMap, useFinance } from "@/lib/finance/context";
import { formatBRL, formatBRLShort, formatDate, formatPct, monthKey, monthLabel } from "@/lib/finance/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Relatórios — FinanceFlow" },
      { name: "description", content: "Analise suas finanças com relatórios detalhados." },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const { data } = useFinance();
  const catMap = useCategoryMap();
  const [preset, setPreset] = useState("this-month");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");

  const range = useMemo(() => {
    const now = new Date();
    const iso = (d: Date) => d.toISOString().slice(0, 10);
    if (preset === "custom") return { from: customFrom, to: customTo };
    if (preset === "this-month") return { from: iso(new Date(now.getFullYear(), now.getMonth(), 1)), to: iso(now) };
    if (preset === "last-month") {
      const f = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const t = new Date(now.getFullYear(), now.getMonth(), 0);
      return { from: iso(f), to: iso(t) };
    }
    if (preset === "3m") return { from: iso(new Date(now.getFullYear(), now.getMonth() - 2, 1)), to: iso(now) };
    if (preset === "6m") return { from: iso(new Date(now.getFullYear(), now.getMonth() - 5, 1)), to: iso(now) };
    if (preset === "year") return { from: `${now.getFullYear()}-01-01`, to: iso(now) };
    return { from: "", to: "" };
  }, [preset, customFrom, customTo]);

  const filtered = useMemo(() => {
    return data.transactions.filter((t) => (!range.from || t.date >= range.from) && (!range.to || t.date <= range.to));
  }, [data.transactions, range]);

  const byMonth = useMemo(() => {
    const m = new Map<string, { income: number; expense: number }>();
    for (const t of filtered) {
      const k = monthKey(t.date);
      const cur = m.get(k) ?? { income: 0, expense: 0 };
      if (t.type === "income") cur.income += t.amount; else cur.expense += t.amount;
      m.set(k, cur);
    }
    return Array.from(m.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([k, v]) => ({ key: k, label: monthLabel(k), ...v, net: v.income - v.expense, savings: v.income > 0 ? ((v.income - v.expense) / v.income) * 100 : 0 }));
  }, [filtered]);

  const expenses = filtered.filter((t) => t.type === "expense");
  const incomes = filtered.filter((t) => t.type === "income");
  const totalExp = expenses.reduce((s, t) => s + t.amount, 0);

  const topCats = useMemo(() => {
    const m = new Map<string, number>();
    for (const t of expenses) m.set(t.categoryId, (m.get(t.categoryId) ?? 0) + t.amount);
    return Array.from(m.entries())
      .map(([id, v]) => ({ id, name: catMap.get(id)?.name ?? "—", icon: catMap.get(id)?.icon ?? "📦", color: catMap.get(id)?.color ?? "#71717A", value: v, pct: totalExp > 0 ? (v / totalExp) * 100 : 0 }))
      .sort((a, b) => b.value - a.value).slice(0, 5);
  }, [expenses, catMap, totalExp]);

  const topTx = useMemo(() => [...filtered].sort((a, b) => b.amount - a.amount).slice(0, 5), [filtered]);

  const weekdayHeat = useMemo(() => {
    const days = [0, 0, 0, 0, 0, 0, 0];
    for (const t of expenses) {
      const [y, m, d] = t.date.split("-").map(Number);
      const dt = new Date(y, m - 1, d);
      days[dt.getDay()] += t.amount;
    }
    const max = Math.max(...days, 1);
    const labels = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    return days.map((v, i) => ({ label: labels[i], value: v, pct: v / max }));
  }, [expenses]);

  const days = Math.max(1, daysBetween(range.from, range.to));
  const avgDaily = totalExp / days;
  const maxExp = expenses.reduce((m, t) => (t.amount > m.amount ? t : m), { amount: 0, description: "—", date: "" } as any);
  const maxInc = incomes.reduce((m, t) => (t.amount > m.amount ? t : m), { amount: 0, description: "—", date: "" } as any);

  const exportCsv = () => {
    const rows = [
      ["Métrica", "Valor"],
      ["Período", `${range.from} a ${range.to}`],
      ["Total entradas", incomes.reduce((s, t) => s + t.amount, 0).toFixed(2)],
      ["Total saídas", totalExp.toFixed(2)],
      ["Média diária", avgDaily.toFixed(2)],
      [],
      ["Mês", "Entradas", "Saídas", "Saldo", "Economia %"],
      ...byMonth.map((m) => [m.label, m.income.toFixed(2), m.expense.toFixed(2), m.net.toFixed(2), m.savings.toFixed(1)]),
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `relatorio-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-[1400px] mx-auto">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Relatórios</h1>
          <p className="text-sm text-muted-foreground">Análise detalhada das suas finanças.</p>
        </div>
        <div className="flex gap-2 items-center flex-wrap">
          <Select value={preset} onValueChange={setPreset}>
            <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="this-month">Este mês</SelectItem>
              <SelectItem value="last-month">Mês passado</SelectItem>
              <SelectItem value="3m">Últimos 3 meses</SelectItem>
              <SelectItem value="6m">Últimos 6 meses</SelectItem>
              <SelectItem value="year">Este ano</SelectItem>
              <SelectItem value="custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>
          {preset === "custom" && (
            <>
              <Input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} className="w-40" />
              <Input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} className="w-40" />
            </>
          )}
          <Button variant="outline" onClick={exportCsv} className="gap-2"><Download className="h-4 w-4" /> Exportar</Button>
        </div>
      </header>

      <Card>
        <CardHeader><CardTitle>Resumo por mês</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-muted-foreground border-b border-border">
              <tr><th className="px-3 py-2 text-left">Mês</th><th className="px-3 py-2 text-right">Entradas</th><th className="px-3 py-2 text-right">Saídas</th><th className="px-3 py-2 text-right">Saldo</th><th className="px-3 py-2 text-right">Economia</th></tr>
            </thead>
            <tbody>
              {byMonth.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-6 text-muted-foreground">Sem dados no período</td></tr>
              ) : byMonth.map((m) => (
                <tr key={m.key} className="border-b border-border">
                  <td className="px-3 py-2 font-medium">{m.label}</td>
                  <td className="px-3 py-2 text-right text-emerald-500 tabular-nums">{formatBRL(m.income)}</td>
                  <td className="px-3 py-2 text-right text-red-500 tabular-nums">{formatBRL(m.expense)}</td>
                  <td className="px-3 py-2 text-right font-semibold tabular-nums">{formatBRL(m.net)}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{formatPct(m.savings)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <section className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Top 5 categorias</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {topCats.length === 0 ? <p className="text-sm text-muted-foreground">Sem dados</p> : topCats.map((c, i) => (
              <div key={c.id} className="flex items-center gap-3">
                <div className="text-sm font-bold text-muted-foreground w-5">{i + 1}</div>
                <div className="text-xl">{c.icon}</div>
                <div className="flex-1">
                  <div className="flex justify-between text-sm"><span className="font-medium">{c.name}</span><span className="tabular-nums">{formatBRL(c.value)}</span></div>
                  <div className="h-1.5 bg-muted rounded-full mt-1 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${c.pct}%`, backgroundColor: c.color }} /></div>
                </div>
                <Badge variant="secondary">{c.pct.toFixed(0)}%</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Top 5 transações</CardTitle></CardHeader>
          <CardContent>
            {topTx.length === 0 ? <p className="text-sm text-muted-foreground">Sem dados</p> : (
              <ul className="divide-y divide-border">
                {topTx.map((t, i) => (
                  <li key={t.id} className="flex items-center gap-3 py-2">
                    <div className="text-sm font-bold text-muted-foreground w-5">{i + 1}</div>
                    <div className="text-xl">{catMap.get(t.categoryId)?.icon ?? "💸"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{t.description}</div>
                      <div className="text-xs text-muted-foreground">{formatDate(t.date)}</div>
                    </div>
                    <div className={t.type === "income" ? "text-emerald-500 font-semibold" : "text-red-500 font-semibold"}>{formatBRL(t.amount)}</div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Gastos por dia da semana</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2">
              {weekdayHeat.map((d) => (
                <div key={d.label} className="text-center space-y-1">
                  <div className="rounded-lg h-20 flex items-end justify-center p-1" style={{ backgroundColor: `rgba(99, 102, 241, ${0.1 + d.pct * 0.9})` }}>
                    <span className="text-[10px] text-foreground/80 tabular-nums">{formatBRLShort(d.value)}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{d.label}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Tendência Entradas x Saídas</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={byMonth}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis dataKey="label" stroke="#71717A" fontSize={12} />
                <YAxis stroke="#71717A" fontSize={12} tickFormatter={(v) => formatBRLShort(v)} />
                <Tooltip contentStyle={{ backgroundColor: "#18181B", border: "1px solid #27272A", borderRadius: 8 }} formatter={(v: number) => formatBRL(v)} />
                <Legend />
                <Line type="monotone" dataKey="income" stroke="#22C55E" strokeWidth={2} name="Entradas" />
                <Line type="monotone" dataKey="expense" stroke="#EF4444" strokeWidth={2} name="Saídas" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 grid-cols-1 md:grid-cols-3">
        <Card><CardContent className="p-5"><div className="text-xs text-muted-foreground">Média diária</div><div className="text-2xl font-bold mt-1">{formatBRL(avgDaily)}</div></CardContent></Card>
        <Card><CardContent className="p-5"><div className="text-xs text-muted-foreground">Maior saída</div><div className="text-2xl font-bold mt-1 text-red-500">{formatBRL(maxExp.amount)}</div><div className="text-xs text-muted-foreground mt-1">{maxExp.description}</div></CardContent></Card>
        <Card><CardContent className="p-5"><div className="text-xs text-muted-foreground">Maior entrada</div><div className="text-2xl font-bold mt-1 text-emerald-500">{formatBRL(maxInc.amount)}</div><div className="text-xs text-muted-foreground mt-1">{maxInc.description}</div></CardContent></Card>
      </section>
    </div>
  );
}

function daysBetween(a: string, b: string) {
  if (!a || !b) return 30;
  const da = new Date(a); const db = new Date(b);
  return Math.max(1, Math.round((db.getTime() - da.getTime()) / 86400000) + 1);
}
