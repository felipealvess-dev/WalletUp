import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  TrendingUp, TrendingDown, Wallet, PiggyBank, ArrowUpRight, ArrowDownRight, Plus,
} from "lucide-react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { useCategoryMap, useFinance } from "@/lib/finance/context";
import { formatBRL, formatBRLShort, formatDate, formatPct, monthKey, monthLabel } from "@/lib/finance/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TransactionModal } from "@/components/TransactionModal";
import { EmptyState } from "@/components/EmptyState";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — FinanceFlow" },
      { name: "description", content: "Visão geral das suas finanças pessoais." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { data, loading } = useFinance();
  const catMap = useCategoryMap();
  const [open, setOpen] = useState(false);

  const stats = useMemo(() => {
    const now = new Date();
    const currentKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

    // Se o mês atual não tem transações, usa o mês mais recente com dados
    const keysWithData = Array.from(new Set(data.transactions.map((t) => monthKey(t.date)))).sort();
    const hasCurrent = keysWithData.includes(currentKey);
    const thisKey = hasCurrent ? currentKey : (keysWithData[keysWithData.length - 1] ?? currentKey);

    const [ty, tm] = thisKey.split("-").map(Number);
    const prevDate = new Date(ty, tm - 2, 1);
    const prevKey = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, "0")}`;

    const monthAgg = (key: string) => {
      const t = data.transactions.filter((x) => monthKey(x.date) === key);
      const inc = t.filter((x) => x.type === "income").reduce((s, x) => s + x.amount, 0);
      const exp = t.filter((x) => x.type === "expense").reduce((s, x) => s + x.amount, 0);
      return { inc, exp, savings: inc > 0 ? ((inc - exp) / inc) * 100 : 0 };
    };
    const cur = monthAgg(thisKey);
    const prv = monthAgg(prevKey);

    const balance = data.transactions.reduce((s, x) => s + (x.type === "income" ? x.amount : -x.amount), 0);
    const prevBalance = data.transactions
      .filter((x) => monthKey(x.date) < thisKey)
      .reduce((s, x) => s + (x.type === "income" ? x.amount : -x.amount), 0);

    const pct = (a: number, b: number) => (b === 0 ? (a > 0 ? 100 : 0) : ((a - b) / Math.abs(b)) * 100);

    return {
      balance, balanceDelta: pct(balance, prevBalance),
      inc: cur.inc, incDelta: pct(cur.inc, prv.inc),
      exp: cur.exp, expDelta: pct(cur.exp, prv.exp),
      savings: cur.savings, savingsDelta: cur.savings - prv.savings,
      thisKey,
    };
  }, [data.transactions]);

  const monthsSeries = useMemo(() => {
    const [ty, tm] = stats.thisKey.split("-").map(Number);
    const anchor = new Date(ty, tm - 1, 1);
    const arr: { key: string; label: string; income: number; expense: number; balance: number }[] = [];
    let running = 0;
    const earliest = new Date(anchor.getFullYear(), anchor.getMonth() - 5, 1);
    const earliestKey = `${earliest.getFullYear()}-${String(earliest.getMonth() + 1).padStart(2, "0")}`;
    running = data.transactions
      .filter((t) => monthKey(t.date) < earliestKey)
      .reduce((s, t) => s + (t.type === "income" ? t.amount : -t.amount), 0);

    for (let i = 5; i >= 0; i--) {
      const d = new Date(anchor.getFullYear(), anchor.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const t = data.transactions.filter((x) => monthKey(x.date) === key);
      const income = t.filter((x) => x.type === "income").reduce((s, x) => s + x.amount, 0);
      const expense = t.filter((x) => x.type === "expense").reduce((s, x) => s + x.amount, 0);
      running += income - expense;
      arr.push({ key, label: monthLabel(key), income, expense, balance: running });
    }
    return arr;
  }, [data.transactions, stats.thisKey]);

  const categoryBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    data.transactions
      .filter((t) => t.type === "expense" && monthKey(t.date) === stats.thisKey)
      .forEach((t) => map.set(t.categoryId, (map.get(t.categoryId) ?? 0) + t.amount));
    return Array.from(map.entries())
      .map(([id, v]) => ({ id, name: catMap.get(id)?.name ?? "—", color: catMap.get(id)?.color ?? "#71717A", value: v }))
      .sort((a, b) => b.value - a.value);
  }, [data.transactions, catMap, stats.thisKey]);

  const dailySeries = useMemo(() => {
    const [ty, tm] = stats.thisKey.split("-").map(Number);
    const daysInMonth = new Date(ty, tm, 0).getDate();
    const arr: { day: string; value: number }[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const iso = `${stats.thisKey}-${String(d).padStart(2, "0")}`;
      const v = data.transactions
        .filter((t) => t.date === iso && t.type === "expense")
        .reduce((s, t) => s + t.amount, 0);
      arr.push({ day: String(d), value: v });
    }
    return arr;
  }, [data.transactions, stats.thisKey]);

  const recent = useMemo(
    () => [...data.transactions].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5),
    [data.transactions]
  );

  if (loading) return <div className="p-6"><SkeletonCards /></div>;

  const cards = [
    { label: "Saldo total", value: formatBRL(stats.balance), delta: stats.balanceDelta, icon: Wallet, accent: "text-primary bg-primary/10" },
    { label: "Entradas do mês", value: formatBRL(stats.inc), delta: stats.incDelta, icon: TrendingUp, accent: "text-emerald-500 bg-emerald-500/10" },
    { label: "Saídas do mês", value: formatBRL(stats.exp), delta: stats.expDelta, icon: TrendingDown, accent: "text-red-500 bg-red-500/10", inverse: true },
    { label: "Taxa de economia", value: formatPct(stats.savings), delta: stats.savingsDelta, icon: PiggyBank, accent: "text-amber-500 bg-amber-500/10", absolute: true },
  ];

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-[1400px] mx-auto">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Olá, {data.settings.profileName} 👋</h1>
          <p className="text-sm text-muted-foreground">Aqui está o resumo das suas finanças.</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2"><Plus className="h-4 w-4" /> Nova transação</Button>
      </header>

      <section className="grid gap-4 grid-cols-1 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => {
          const up = c.delta >= 0;
          const good = c.inverse ? !up : up;
          return (
            <Card key={c.label}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", c.accent)}>
                    <c.icon className="h-5 w-5" />
                  </div>
                  <div className={cn("flex items-center gap-1 text-xs font-medium", good ? "text-emerald-500" : "text-red-500")}>
                    {up ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
                    {c.absolute ? `${c.delta.toFixed(1).replace(".", ",")} pp` : `${Math.abs(c.delta).toFixed(1).replace(".", ",")}%`}
                  </div>
                </div>
                <div className="mt-4 text-xs text-muted-foreground">{c.label}</div>
                <div className="text-2xl font-bold mt-1">{c.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <section className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Evolução do saldo (6 meses)</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthsSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis dataKey="label" stroke="#71717A" fontSize={12} />
                <YAxis stroke="#71717A" fontSize={12} tickFormatter={(v) => formatBRLShort(v)} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatBRL(v)} />
                <Line type="monotone" dataKey="balance" stroke="#6366F1" strokeWidth={2.5} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Entradas x Saídas</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthsSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis dataKey="label" stroke="#71717A" fontSize={12} />
                <YAxis stroke="#71717A" fontSize={12} tickFormatter={(v) => formatBRLShort(v)} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatBRL(v)} />
                <Legend />
                <Bar dataKey="income" fill="#22C55E" name="Entradas" radius={[6, 6, 0, 0]} />
                <Bar dataKey="expense" fill="#EF4444" name="Saídas" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Gastos por categoria (mês atual)</CardTitle></CardHeader>
          <CardContent className="h-72">
            {categoryBreakdown.length === 0 ? (
              <EmptyState title="Sem gastos este mês" description="Adicione transações para visualizar." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={categoryBreakdown} dataKey="value" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>
                    {categoryBreakdown.map((c) => <Cell key={c.id} fill={c.color} />)}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatBRL(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Tendência diária do mês</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailySeries}>
                <defs>
                  <linearGradient id="gExp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366F1" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#6366F1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis dataKey="day" stroke="#71717A" fontSize={12} />
                <YAxis stroke="#71717A" fontSize={12} tickFormatter={(v) => formatBRLShort(v)} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatBRL(v)} />
                <Area type="monotone" dataKey="value" stroke="#6366F1" fill="url(#gExp)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </section>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Transações recentes</CardTitle>
          <Link to="/transactions" className="text-sm text-primary hover:underline">Ver todas</Link>
        </CardHeader>
        <CardContent>
          {recent.length === 0 ? (
            <EmptyState title="Nenhuma transação" description="Comece adicionando sua primeira transação." action={<Button onClick={() => setOpen(true)}>Adicionar</Button>} />
          ) : (
            <ul className="divide-y divide-border">
              {recent.map((t) => {
                const c = catMap.get(t.categoryId);
                return (
                  <li key={t.id} className="flex items-center gap-3 py-3">
                    <div className="h-10 w-10 rounded-xl flex items-center justify-center text-lg" style={{ backgroundColor: (c?.color ?? "#71717A") + "22" }}>
                      {c?.icon ?? "💸"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{t.description}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-2">
                        <Badge variant="secondary" className="font-normal">{c?.name ?? "—"}</Badge>
                        <span>{formatDate(t.date)}</span>
                      </div>
                    </div>
                    <div className={cn("font-semibold tabular-nums", t.type === "income" ? "text-emerald-500" : "text-red-500")}>
                      {t.type === "income" ? "+" : "−"} {formatBRL(t.amount)}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <TransactionModal open={open} onOpenChange={setOpen} />
    </div>
  );
}

const tooltipStyle = {
  backgroundColor: "#18181B",
  border: "1px solid #27272A",
  borderRadius: 8,
  color: "#FAFAFA",
  fontSize: 12,
};

function SkeletonCards() {
  return (
    <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 xl:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="h-32 rounded-xl bg-card border border-border animate-pulse" />
      ))}
    </div>
  );
}
