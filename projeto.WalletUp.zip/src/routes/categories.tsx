import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useFinance } from "@/lib/finance/context";
import { formatBRL, monthKey } from "@/lib/finance/format";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import type { Category, TxType } from "@/lib/finance/types";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Categorias — FinanceFlow" },
      { name: "description", content: "Organize categorias e limites de orçamento." },
    ],
  }),
  component: CategoriesPage,
});

const ICONS = ["🏠","🍔","🚗","💊","🎓","🎮","👕","💡","💰","📦","💼","💻","📈","🎁","🏦","✈️","☕","🐾","🛒","📱"];
const COLORS = ["#6366F1","#22C55E","#EF4444","#F97316","#0EA5E9","#8B5CF6","#EC4899","#10B981","#EAB308","#71717A"];

function CategoriesPage() {
  const { data, addCategory, updateCategory, deleteCategory } = useFinance();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Category | undefined>();

  const thisKey = monthKey(new Date().toISOString().slice(0, 10));

  const stats = useMemo(() => {
    const m = new Map<string, { total: number; count: number }>();
    for (const t of data.transactions) {
      if (monthKey(t.date) !== thisKey) continue;
      const cur = m.get(t.categoryId) ?? { total: 0, count: 0 };
      cur.total += t.amount; cur.count += 1;
      m.set(t.categoryId, cur);
    }
    return m;
  }, [data.transactions, thisKey]);

  const handleDelete = (c: Category) => {
    if (!c.isCustom) return toast.error("Categorias padrão não podem ser excluídas");
    deleteCategory(c.id);
    toast.success("Categoria excluída");
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-[1400px] mx-auto">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Categorias</h1>
          <p className="text-sm text-muted-foreground">Defina cores, ícones e limites de orçamento.</p>
        </div>
        <Button onClick={() => { setEditing(undefined); setOpen(true); }} className="gap-2"><Plus className="h-4 w-4" /> Nova categoria</Button>
      </header>

      {(["expense", "income"] as TxType[]).map((type) => (
        <section key={type} className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            {type === "expense" ? "Saídas" : "Entradas"}
          </h2>
          <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {data.categories.filter((c) => c.type === type).map((c) => {
              const s = stats.get(c.id) ?? { total: 0, count: 0 };
              const pct = c.budget ? Math.min(100, (s.total / c.budget) * 100) : 0;
              const color = pct < 70 ? "#22C55E" : pct < 90 ? "#EAB308" : "#EF4444";
              return (
                <Card key={c.id}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-11 w-11 rounded-xl flex items-center justify-center text-xl" style={{ backgroundColor: c.color + "22" }}>{c.icon}</div>
                        <div>
                          <div className="font-medium">{c.name}</div>
                          <div className="text-xs text-muted-foreground">{s.count} transação(ões)</div>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => { setEditing(c); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        {c.isCustom && <Button variant="ghost" size="icon" onClick={() => handleDelete(c)}><Trash2 className="h-4 w-4 text-red-500" /></Button>}
                      </div>
                    </div>
                    <div className="text-2xl font-bold tabular-nums">{formatBRL(s.total)}</div>
                    {c.budget ? (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Limite: {formatBRL(c.budget)}</span>
                          <span style={{ color }}>{pct.toFixed(0)}%</span>
                        </div>
                        <Progress value={pct} className="h-2" style={{ ["--progress-color" as any]: color }} />
                      </div>
                    ) : (
                      <div className="text-xs text-muted-foreground">Sem orçamento definido</div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      ))}

      <CategoryDialog open={open} onOpenChange={setOpen} editing={editing} onSave={(payload, id) => {
        if (id) { updateCategory(id, payload); toast.success("Categoria atualizada"); }
        else { addCategory(payload as any); toast.success("Categoria criada"); }
      }} />
    </div>
  );
}

function CategoryDialog({ open, onOpenChange, editing, onSave }: {
  open: boolean; onOpenChange: (o: boolean) => void; editing?: Category;
  onSave: (c: Omit<Category, "id">, id?: string) => void;
}) {
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("📦");
  const [color, setColor] = useState("#6366F1");
  const [type, setType] = useState<TxType>("expense");
  const [budget, setBudget] = useState("");

  useEffect(() => {
    if (!open) return;
    if (editing) {
      setName(editing.name); setIcon(editing.icon); setColor(editing.color);
      setType(editing.type); setBudget(editing.budget ? String(editing.budget) : "");
    } else {
      setName(""); setIcon("📦"); setColor("#6366F1"); setType("expense"); setBudget("");
    }
  }, [open, editing]);

  const submit = () => {
    if (!name.trim()) return toast.error("Nome obrigatório");
    const budgetNum = budget ? parseFloat(budget.replace(",", ".")) : undefined;
    onSave({ name: name.trim(), icon, color, type, budget: budgetNum, isCustom: editing?.isCustom ?? true }, editing?.id);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>{editing ? "Editar categoria" : "Nova categoria"}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="grid gap-2"><Label>Nome</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Tipo</Label>
              <Select value={type} onValueChange={(v) => setType(v as TxType)} disabled={!!editing}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Saída</SelectItem>
                  <SelectItem value="income">Entrada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Orçamento (R$)</Label>
              <Input value={budget} onChange={(e) => setBudget(e.target.value)} placeholder="opcional" />
            </div>
          </div>
          <div className="grid gap-2">
            <Label>Ícone</Label>
            <div className="grid grid-cols-10 gap-1">
              {ICONS.map((i) => (
                <button key={i} type="button" onClick={() => setIcon(i)} className={"h-9 rounded-md text-lg hover:bg-accent " + (icon === i ? "bg-primary/20 ring-1 ring-primary" : "")}>{i}</button>
              ))}
            </div>
          </div>
          <div className="grid gap-2">
            <Label>Cor</Label>
            <div className="flex gap-2 flex-wrap">
              {COLORS.map((c) => (
                <button key={c} type="button" onClick={() => setColor(c)} className={"h-8 w-8 rounded-full " + (color === c ? "ring-2 ring-offset-2 ring-offset-card ring-foreground" : "")} style={{ backgroundColor: c }} />
              ))}
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button className="flex-1" onClick={submit}>Salvar</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
