export type TxType = "income" | "expense";

export type PaymentMethod =
  | "cash"
  | "credit"
  | "debit"
  | "pix"
  | "transfer";

export type Recurrence = "none" | "daily" | "weekly" | "monthly" | "yearly";

export interface Category {
  id: string;
  name: string;
  icon: string; // emoji
  color: string; // hex
  type: TxType;
  isCustom?: boolean;
  budget?: number; // monthly limit
}

export interface Transaction {
  id: string;
  type: TxType;
  description: string;
  amount: number;
  categoryId: string;
  date: string; // ISO yyyy-mm-dd
  payment: PaymentMethod;
  notes?: string;
  recurrence: Recurrence;
  createdAt: string;
}

export interface Settings {
  appName: string;
  currency: string;
  profileName: string;
  theme: "dark" | "light";
  budgetAlerts: boolean;
}

export interface FinanceData {
  transactions: Transaction[];
  categories: Category[];
  settings: Settings;
}
