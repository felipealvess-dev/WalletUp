import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { loadData, saveData } from "./storage";
import type { Category, FinanceData, Settings, Transaction } from "./types";

interface Ctx {
  data: FinanceData;
  loading: boolean;
  addTransaction: (t: Omit<Transaction, "id" | "createdAt">) => void;
  updateTransaction: (id: string, t: Omit<Transaction, "id" | "createdAt">) => void;
  deleteTransaction: (id: string) => Transaction | undefined;
  deleteMany: (ids: string[]) => void;
  restoreTransaction: (t: Transaction) => void;
  addCategory: (c: Omit<Category, "id">) => void;
  updateCategory: (id: string, patch: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  replaceAll: (d: FinanceData) => void;
  reset: () => void;
}

const FinanceCtx = createContext<Ctx | null>(null);

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

// Garante data sempre no formato yyyy-mm-dd (aceita dd/mm/yyyy ou ISO completo)
const normalizeDate = (input: string): string => {
  if (!input) return "";
  if (/^\d{4}-\d{2}-\d{2}/.test(input)) return input.slice(0, 10);
  const br = input.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (br) return `${br[3]}-${br[2]}-${br[1]}`;
  const d = new Date(input);
  if (!isNaN(d.getTime())) {
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }
  return input;
};

const normalizeTx = <T extends { date: string; amount: number | string }>(t: T): T => ({
  ...t,
  date: normalizeDate(t.date),
  amount: typeof t.amount === "string" ? parseFloat(String(t.amount).replace(",", ".")) || 0 : t.amount,
});

export function FinanceProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<FinanceData>(() => ({
    transactions: [],
    categories: [],
    settings: { appName: "FinanceFlow", currency: "BRL", profileName: "Visitante", theme: "dark", budgetAlerts: true },
  }));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const d = loadData();
    setData(d);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!loading) saveData(data);
  }, [data, loading]);

  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.classList.toggle("light", data.settings.theme === "light");
  }, [data.settings.theme]);

  const api: Ctx = useMemo(() => ({
    data,
    loading,
    addTransaction: (t) => setData((d) => ({
      ...d,
      transactions: [{ ...normalizeTx(t), id: uid(), createdAt: new Date().toISOString() }, ...d.transactions],
    })),
    updateTransaction: (id, t) => setData((d) => ({
      ...d,
      transactions: d.transactions.map((x) => x.id === id ? { ...x, ...normalizeTx(t) } : x),
    })),
    deleteTransaction: (id) => {
      let removed: Transaction | undefined;
      setData((d) => {
        removed = d.transactions.find((x) => x.id === id);
        return { ...d, transactions: d.transactions.filter((x) => x.id !== id) };
      });
      return removed;
    },
    deleteMany: (ids) => setData((d) => ({ ...d, transactions: d.transactions.filter((x) => !ids.includes(x.id)) })),
    restoreTransaction: (t) => setData((d) => ({ ...d, transactions: [t, ...d.transactions] })),
    addCategory: (c) => setData((d) => ({ ...d, categories: [...d.categories, { ...c, id: uid(), isCustom: true }] })),
    updateCategory: (id, patch) => setData((d) => ({
      ...d,
      categories: d.categories.map((c) => c.id === id ? { ...c, ...patch } : c),
    })),
    deleteCategory: (id) => setData((d) => ({ ...d, categories: d.categories.filter((c) => c.id !== id) })),
    updateSettings: (patch) => setData((d) => ({ ...d, settings: { ...d.settings, ...patch } })),
    replaceAll: (n) => setData(n),
    reset: () => {
      localStorage.removeItem("financeflow_data");
      setData(loadData());
    },
  }), [data, loading]);

  return <FinanceCtx.Provider value={api}>{children}</FinanceCtx.Provider>;
}

export function useFinance() {
  const ctx = useContext(FinanceCtx);
  if (!ctx) throw new Error("useFinance must be used inside FinanceProvider");
  return ctx;
}

export function useCategoryMap() {
  const { data } = useFinance();
  return useMemo(() => new Map(data.categories.map((c) => [c.id, c])), [data.categories]);
}
