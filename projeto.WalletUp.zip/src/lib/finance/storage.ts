import { DEFAULT_CATEGORIES } from "./categories";
import type { FinanceData } from "./types";

const KEY = "financeflow_data";

const defaults = (): FinanceData => ({
  transactions: [],
  categories: DEFAULT_CATEGORIES,
  settings: {
    appName: "FinanceFlow",
    currency: "BRL",
    profileName: "Visitante",
    theme: "dark",
    budgetAlerts: true,
  },
});

export function loadData(): FinanceData {
  if (typeof window === "undefined") return defaults();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      const d = defaults();
      localStorage.setItem(KEY, JSON.stringify(d));
      return d;
    }
    const parsed = JSON.parse(raw) as FinanceData;
    // merge any new default categories
    const ids = new Set(parsed.categories.map((c) => c.id));
    for (const c of DEFAULT_CATEGORIES) if (!ids.has(c.id)) parsed.categories.push(c);
    return parsed;
  } catch {
    return defaults();
  }
}

export function saveData(d: FinanceData) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(d));
}

export function clearData() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(KEY);
}
