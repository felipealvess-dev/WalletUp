import type { Transaction } from "./types";

const expenseCats = [
  "cat-housing","cat-food","cat-transport","cat-health","cat-fun",
  "cat-clothes","cat-bills","cat-education","cat-other-out",
];
const incomeCats = ["cat-salary","cat-freelance","cat-returns","cat-other-in"];
const payments = ["cash","credit","debit","pix","transfer"] as const;

const expenseSamples: Array<[string, string, number]> = [
  ["Aluguel", "cat-housing", 1800],
  ["Conta de luz", "cat-bills", 180],
  ["Internet", "cat-bills", 120],
  ["Supermercado", "cat-food", 450],
  ["Restaurante", "cat-food", 85],
  ["iFood", "cat-food", 60],
  ["Uber", "cat-transport", 35],
  ["Gasolina", "cat-transport", 200],
  ["Farmácia", "cat-health", 75],
  ["Academia", "cat-health", 110],
  ["Netflix", "cat-fun", 55],
  ["Cinema", "cat-fun", 70],
  ["Roupa nova", "cat-clothes", 220],
  ["Curso online", "cat-education", 150],
  ["Livro", "cat-education", 60],
];
const incomeSamples: Array<[string, string, number]> = [
  ["Salário", "cat-salary", 6500],
  ["Freelance projeto", "cat-freelance", 1500],
  ["Dividendos", "cat-returns", 320],
  ["Presente família", "cat-other-in", 200],
];

const pad = (n: number) => String(n).padStart(2, "0");

export function generateSeedTransactions(): Transaction[] {
  const out: Transaction[] = [];
  const now = new Date();
  let counter = 0;
  for (let monthsBack = 2; monthsBack >= 0; monthsBack--) {
    const base = new Date(now.getFullYear(), now.getMonth() - monthsBack, 1);
    const daysInMonth = new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate();
    const lastDay = monthsBack === 0 ? now.getDate() : daysInMonth;

    // income: salary on day 5, plus 1-2 randoms
    for (const [desc, cat, amt] of incomeSamples) {
      if (Math.random() > 0.4 || cat === "cat-salary") {
        const day = cat === "cat-salary" ? 5 : Math.min(lastDay, 1 + Math.floor(Math.random() * lastDay));
        out.push(mk(++counter, base, day, "income", desc, cat, amt));
      }
    }
    // 12-18 expenses per month
    const count = 12 + Math.floor(Math.random() * 7);
    for (let i = 0; i < count; i++) {
      const [desc, cat, amt] = expenseSamples[Math.floor(Math.random() * expenseSamples.length)];
      const day = Math.min(lastDay, 1 + Math.floor(Math.random() * lastDay));
      const variation = 0.7 + Math.random() * 0.6;
      out.push(mk(++counter, base, day, "expense", desc, cat, Math.round(amt * variation * 100) / 100));
    }
  }
  return out;

  function mk(id: number, base: Date, day: number, type: "income" | "expense", desc: string, cat: string, amount: number): Transaction {
    const iso = `${base.getFullYear()}-${pad(base.getMonth() + 1)}-${pad(day)}`;
    return {
      id: `seed-${id}`,
      type,
      description: desc,
      amount,
      categoryId: cat,
      date: iso,
      payment: payments[Math.floor(Math.random() * payments.length)],
      recurrence: "none",
      createdAt: new Date().toISOString(),
    };
  }
}
