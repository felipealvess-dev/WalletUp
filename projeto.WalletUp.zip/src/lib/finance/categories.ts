import type { Category } from "./types";

export const DEFAULT_CATEGORIES: Category[] = [
  // expenses
  { id: "cat-housing", name: "Moradia", icon: "🏠", color: "#6366F1", type: "expense" },
  { id: "cat-food", name: "Alimentação", icon: "🍔", color: "#F97316", type: "expense" },
  { id: "cat-transport", name: "Transporte", icon: "🚗", color: "#0EA5E9" , type: "expense"},
  { id: "cat-health", name: "Saúde", icon: "💊", color: "#10B981", type: "expense" },
  { id: "cat-education", name: "Educação", icon: "🎓", color: "#8B5CF6", type: "expense" },
  { id: "cat-fun", name: "Entretenimento", icon: "🎮", color: "#EC4899", type: "expense" },
  { id: "cat-clothes", name: "Vestuário", icon: "👕", color: "#F59E0B", type: "expense" },
  { id: "cat-bills", name: "Contas", icon: "💡", color: "#EAB308", type: "expense" },
  { id: "cat-invest", name: "Investimentos", icon: "💰", color: "#22C55E", type: "expense" },
  { id: "cat-other-out", name: "Outros", icon: "📦", color: "#71717A", type: "expense" },
  // income
  { id: "cat-salary", name: "Salário", icon: "💼", color: "#22C55E", type: "income" },
  { id: "cat-freelance", name: "Freelance", icon: "💻", color: "#6366F1", type: "income" },
  { id: "cat-returns", name: "Retorno de Investimentos", icon: "📈", color: "#10B981", type: "income" },
  { id: "cat-gifts", name: "Presentes", icon: "🎁", color: "#EC4899", type: "income" },
  { id: "cat-other-in", name: "Outras Entradas", icon: "🏦", color: "#0EA5E9", type: "income" },
];

export const PAYMENT_LABEL: Record<string, string> = {
  cash: "Dinheiro",
  credit: "Cartão de Crédito",
  debit: "Cartão de Débito",
  pix: "PIX",
  transfer: "Transferência",
};
